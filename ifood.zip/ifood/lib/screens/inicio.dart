import 'package:flutter/material.dart';
import 'carrinho.dart';

class TelaInicial extends StatefulWidget {
  const TelaInicial({super.key});

  @override
  State<TelaInicial> createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> {
  int _currentTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      // Usando SafeArea para respeitar a barra de status do dispositivo
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // --- ÁREA DE CATEGORIAS HORIZONTAL ---
              SizedBox(
                height: 50,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    // Botão circular de menu
                    Container(
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        icon: const SizedBox.shrink(),
                        onPressed: () {},
                      ),
                    ),
                    // Cápsulas (Pill Buttons) de Categorias
                    _buildCategoryPill('Mercado'),
                    _buildCategoryPill('Restaurantes'),
                    _buildCategoryPill('Farmácia'),
                    _buildCategoryPill('Pet'),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // --- SEÇÃO DE DESTAQUE ---
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Famosos no App',
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black),
                        ),
                        Text(
                          'As melhores marcas da sua região',
                          style: TextStyle(fontSize: 14, color: Colors.grey),
                        ),
                      ],
                    ),
                    TextButton(
                      onPressed: () {},
                      child: const Text('Ver mais', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                    )
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // --- CARROSSEL HORIZONTAL DE MARCAS ---
              SizedBox(
                height: 110,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    _buildBrandItem('Burger King', Colors.orange),
                    _buildBrandItem('McDonalds', Colors.yellow[700]!),
                    _buildBrandItem('Subway', Colors.green),
                    _buildBrandItem('Pizza Hut', Colors.red),
                    _buildBrandItem('Giraffas', Colors.brown),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // --- ÁREA DE FILTROS RÁPIDOS (CHIPS VARYING SIZE) ---
              SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    _buildFilterChip('Filtro'),
                    _buildFilterChip('Entrega Grátis'),
                    _buildFilterChip('Ordenar por Distância'),
                    _buildFilterChip('Cupons Disponíveis'),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // --- SEÇÃO PRINCIPAL: LISTA VERTICAL DE ESTABELECIMENTOS ---
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  children: [
                    _buildMerchantItem(
                      name: 'Padaria Central e Confeitaria',
                      rating: '4.8',
                      time: '25-35 min',
                      fee: 'Grátis',
                      promo: 'Super Cupom R\$10',
                      color: Colors.amber,
                    ),
                    _buildMerchantItem(
                      name: 'Sushi Lounge Delivery',
                      rating: '4.9',
                      time: '40-50 min',
                      fee: 'R\$ 4,99',
                      promo: 'Frete Grátis acima de R\$50',
                      color: Colors.redAccent,
                    ),
                    _buildMerchantItem(
                      name: 'Espetinho do Juarez',
                      rating: '4.5',
                      time: '15-25 min',
                      fee: 'R\$ 2,00',
                      promo: null,
                      color: Colors.orange,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),

      // --- BOTÃO FLUTUANTE (FAB) PROMOCIONAL ---
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navega para a Tela de Carrinho
          Navigator.push(context, MaterialPageRoute(builder: (context) => const Carrinho()));
        },
        backgroundColor: Colors.purple,
        shape: const CircleBorder(),
        elevation: 6,
        child: const SizedBox.shrink(),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,

      // --- BARRA DE NAVEGAÇÃO FIXA INFERIOR ---
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentTab,
        onTap: (index) {
          setState(() {
            _currentTab = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        selectedItemColor: Colors.black87,
        unselectedItemColor: Colors.grey[400],
        showUnselectedLabels: true,
        items: [
          const BottomNavigationBarItem(icon: SizedBox.shrink(), label: 'Início'),
          const BottomNavigationBarItem(icon: SizedBox.shrink(), label: 'Busca'),
          BottomNavigationBarItem(
            icon: SizedBox(
              child: Stack(
                children: [
                  const SizedBox.shrink(),
                  // Indicador de notificação (badge)
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                      padding: const EdgeInsets.all(1),
                      decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                      constraints: const BoxConstraints(minWidth: 8, minHeight: 8),
                    ),
                  )
                ],
              ),
            ),
            label: 'Pedidos',
          ),
          const BottomNavigationBarItem(icon: SizedBox.shrink(), label: 'Perfil'),
        ],
      ),
    );
  }

  // Helpers de Construção de Widgets da Tela Inicial
  Widget _buildCategoryPill(String label) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(50),
      ),
      child: Row(
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildBrandItem(String title, Color color) {
    return Container(
      width: 75,
      margin: const EdgeInsets.only(right: 14),
      child: Column(
        children: [
          Container(
            width: 65,
            height: 65,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.2), shape: BoxShape.circle),
          ),
          const SizedBox(height: 6),
          Text(
            title,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12, color: Colors.black87),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String text) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey[200]!),
        borderRadius: BorderRadius.circular(50),
      ),
      child: Text(text, style: const TextStyle(fontSize: 13, color: Colors.black87)),
    );
  }

  Widget _buildMerchantItem({
    required String name,
    required String rating,
    required String time,
    required String fee,
    required String? promo,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Imagem Quadrada com cantos arredondados
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          const SizedBox(width: 16),
          // Área Central de Informações
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                // Linha de Info Secundária
                Row(
                  children: [
                    Text(rating, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.amber)),
                    const SizedBox(width: 8),
                    Text('•  $time', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                    const SizedBox(width: 8),
                    Text('•  $fee', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                ),
                if (promo != null) ...[
                  const SizedBox(height: 6),
                  // Etiqueta Promocional Cápsula
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.green[50],
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Text(
                      promo,
                      style: TextStyle(fontSize: 11, color: Colors.green[700], fontWeight: FontWeight.w600),
                    ),
                  ),
                ]
              ],
            ),
          ),
          // Ícone de ação à direita
          IconButton(
            icon: const SizedBox.shrink(),
            onPressed: () {},
          )
        ],
      ),
    );
  }
}