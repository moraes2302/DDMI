import 'package:flutter/material.dart';
import 'fimPedido.dart';

class Carrinho extends StatelessWidget {
  const Carrinho({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      // CABEÇALHO MINIMALISTA
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const SizedBox.shrink(),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'SACOLA',
          style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.2),
        ),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text('Limpar', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w500)),
          ),
        ],
      ),
      body: Stack(
        children: [
          // Conteúdo rolável deixando espaço para a barra fixa debaixo
          SingleChildScrollView(
            padding: const EdgeInsets.only(bottom: 120), 
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // --- RESUMO DO ESTABELECIMENTO ---
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(color: Colors.amber[100], shape: BoxShape.circle),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Padaria Central e Confeitaria',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Adicionar', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                      )
                    ],
                  ),
                ),

                const Divider(height: 1, color: Color(0xFFF5F5F5)),

                // --- SEÇÃO PRINCIPAL: ITENS ADICIONADOS ---
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Itens adicionados',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 16),

                      // Item 1 do Carrinho
                      _buildCartItem(
                        name: 'Croissant de Chocolate Belga',
                        description: 'Massa folhada recheada com chocolate premium trufado.',
                        price: 'R\$ 14,90',
                        color: Colors.brown,
                        quantity: 2,
                        subitems: ['1x Extra Calda de Chocolate', '1x Embalagem para presente'],
                      ),

                      const SizedBox(height: 20),

                      // Item 2 do Carrinho
                      _buildCartItem(
                        name: 'Suco Natural de Laranja 500ml',
                        description: 'Suco 100% natural, sem adição de açúcar.',
                        price: 'R\$ 9,00',
                        color: Colors.orange,
                        quantity: 1,
                        subitems: ['1x Sem Gelo'],
                      ),
                    ],
                  ),
                ),

                // --- AÇÃO CENTRALIZADA PARA ADICIONAR MAIS PRODUTOS ---
                Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24),
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text(
                        'Adicionar mais produtos',
                        style: TextStyle(color: Colors.red, fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),

                // --- SEÇÃO DE RECOMENDAÇÕES (CARROSSEL HORIZONTAL) ---
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    'Destaques para acompanhar',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 190,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    children: [
                      _buildSuggestionCard('Café Espresso', 'R\$ 6,50', Colors.brown),
                      _buildSuggestionCard('Pão de Queijo', 'R\$ 4,50', Colors.amber),
                      _buildSuggestionCard('Bolo de Cenoura', 'R\$ 8,00', Colors.orange),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // --- BARRA FIXA INFERIOR (RESUMO FINANCEIRO + BOTÃO DE COMPRA) ---
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(color: Colors.black.withValues(alpha: 0.05), offset: const Offset(0, -4), blurRadius: 10)
                ],
              ),
              child: Row(
                children: [
                  // Resumo financeiro esquerdo
                  const Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Total com entrega', style: TextStyle(color: Colors.grey, fontSize: 12)),
                      Text('R\$ 38,80', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black)),
                      Text('3 itens', style: TextStyle(color: Colors.grey, fontSize: 12)),
                    ],
                  ),
                  const SizedBox(width: 24),
                  // Botão de Ação Principal Direito
                  Expanded(
                    child: SizedBox(
                      height: 54,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 0,
                        ),
                        onPressed: () {
                          // Navega para a tela de finalização de compra / checkout
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const FinalizarPedido()));
                        },
                        child: const Text(
                          'Continuar',
                          style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  // Helpers de Construção de Widgets da Tela de Carrinho
  Widget _buildCartItem({
    required String name,
    required String description,
    required String price,
    required Color color,
    required int quantity,
    required List<String> subitems,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Imagem quadrada arredondada
            Container(
              width: 65,
              height: 65,
              decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
            ),
            const SizedBox(width: 12),
            // Dados do Item
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 4),
                  Text(description, style: const TextStyle(color: Colors.grey, fontSize: 12), maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 6),
                  Text(price, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.black87)),
                ],
              ),
            ),
            const SizedBox(width: 8),
            // Controles de Quantidade Container
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  InkWell(
                    onTap: () {},
                    child: const SizedBox.shrink(),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Text('$quantity', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  ),
                  InkWell(
                    onTap: () {},
                    child: const SizedBox.shrink(),
                  ),
                ],
              ),
            )
          ],
        ),
        // Sub-itens (Componentes selecionados)
        if (subitems.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(left: 77, top: 8),
            child: Column(
              children: subitems.map((sub) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(4)),
                      child: const Text('1', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(sub, style: const TextStyle(color: Colors.grey, fontSize: 12))),
                  ],
                ),
              )).toList(),
            ),
          )
      ],
    );
  }

  Widget _buildSuggestionCard(String title, String price, Color color) {
    return Container(
      width: 130,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[100]!),
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Imagem Superior
              Container(
                height: 90,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(price, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.black)),
                    const SizedBox(height: 2),
                    Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey), maxLines: 2, overflow: TextOverflow.ellipsis),
                  ],
                ),
              )
            ],
          ),
          // Botão Circular Flutuante de Adição (+)
          Positioned(
            top: 75,
            right: 8,
            child: Container(
              width: 30,
              height: 30,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: const Icon(Icons.add, size: 18, color: Colors.red),
            ),
          )
        ],
      ),
    );
  }
}