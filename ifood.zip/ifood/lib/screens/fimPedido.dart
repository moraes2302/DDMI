import 'package:flutter/material.dart';

class FinalizarPedido extends StatelessWidget {
  const FinalizarPedido({super.key});

  @override
  Widget build(BuildContext context) {
    // Mantendo a consistência visual de design limpo, branco e vermelho para a etapa final
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const SizedBox.shrink(),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'REVISÃO E PAGAMENTO',
          style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.2),
        ),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Endereço de Entrega', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Avenida Paulista, 1000', style: TextStyle(fontWeight: FontWeight.w600)),
                          Text('Bela Vista - São Paulo/SP', style: TextStyle(color: Colors.grey, fontSize: 13)),
                        ],
                      ),
                    ),
                    TextButton(onPressed: () {}, child: const Text('Alterar', style: TextStyle(color: Colors.red)))
                  ],
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Divider(color: Color(0xFFF5F5F5)),
                ),
                const Text('Forma de Pagamento', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const SizedBox.shrink(),
                  title: const Text('Cartão de Crédito (Visa)'),
                  subtitle: const Text('** ** ** 4321'),
                  trailing: const SizedBox.shrink(),
                  onTap: () {},
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Divider(color: Color(0xFFF5F5F5)),
                ),
                const Text('Resumo dos Valores', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _buildSummaryRow('Subtotal', 'R\$ 33,80'),
                _buildSummaryRow('Taxa de entrega', 'R\$ 5,00'),
                const Divider(),
                _buildSummaryRow('Total', 'R\$ 38,80', isTotal: true),
              ],
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(16),
              color: Colors.white,
              child: SizedBox(
                height: 54,
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  onPressed: () {
                    // Feedback de sucesso
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Pedido enviado com sucesso!'), backgroundColor: Colors.green),
                    );
                    // Retorna para a tela inicial limpando a pilha
                    Navigator.of(context).popUntil((route) => route.isFirst);
                  },
                  child: const Text(
                    'Fazer Pedido',
                    style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: isTotal ? 16 : 14, fontWeight: isTotal ? FontWeight.bold : FontWeight.normal)),
          Text(value, style: TextStyle(fontSize: isTotal ? 18 : 14, fontWeight: isTotal ? FontWeight.bold : FontWeight.w600)),
        ],
      ),
    );
  }
}